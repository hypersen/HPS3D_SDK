//
//  AppDelegate.swift
//  Demo
//
//  Created by 修齐 on 2023/3/14.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    public var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = HomeVC()
        window?.makeKeyAndVisible()
        
        return true
    }


}

