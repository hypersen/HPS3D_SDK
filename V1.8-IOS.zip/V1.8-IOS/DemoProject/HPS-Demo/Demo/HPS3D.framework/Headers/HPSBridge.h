//
//  HPSBridge.h
//  HPS3D
//
//  Created by 修齐 on 2023/3/7.
//

#import <Foundation/Foundation.h>
#include "HPSBridge.h"
#import "HPSSetting.h"
#import <UIKit/UIKit.h>
#import "HPSCaptureResult.h"

@interface HPSBridge : NSObject

@property (nonatomic, copy) void(^block)(HPSCaptureResult *result, HPSLocation *location);

@property (nonatomic, assign) int locationX;
@property (nonatomic, assign) int locationY;

+ (instancetype)shared;


- (int)bridgeBlock;

/// usb connect
+ (int)bridgeUSBConnect:(int *)deviceId port:(NSString *)port;

/// ethernet connect
+ (int)bridgeEthernetConnect:(NSString *)ip port:(NSString *)port deviceId:(int *)deviceId;

/// disconnect
+ (int)bridgeColse:(int)deviceId;

/// start capture
- (int)bridgeStartCapture:(int)deviceId;

/// stop capture
+ (int)bridgeStopCapture:(int)deviceId;

///  capture is start
+ (BOOL)bridgeCaptureIsStarted:(int)deviceId;

/// single capture
+ (int)bridgeSingleCapture:(int)deviceId hanlder:(void(^)(HPSCaptureResult *))block;

/// set device user id
+ (int)bridgeUserId:(int)deviceId userId:(int)userId;

/// set multi camera code
+ (int)bridgeCameraCode:(int)deviceId code:(int)code;

/// set group id
+ (int)bridgeGroupId:(int)deviceId groupId:(int)groupId;

/// set distanceoffset
+ (int)bridgeDistanceOffset:(int)deviceId offset:(int16_t)offset;

/// set distance filter
+ (int)bridgeDistanceFilter:(int)deviceId enable:(BOOL)enable filter:(float)filter;

/// set smooth filter
+ (int)bridgeSmoothFilter:(int)deviceId type:(int)type filter:(int)filter;

/// set opticalPathCalibration
+ (int)bridgeOpticalPath:(int)deviceId enable:(BOOL)enable;

/// export setting
+ (int)bridgeExport:(int)deviceId hanlder:(void(^)(HPSSetting *))block;

/// save setting
+ (int)bridgeSaveSetting:(int)deviceId;

/// fetch connect status
+ (BOOL)bridgeisConnected:(int)deviceId;

/// fetch sdk version
+ (NSString *)bridgeSDKVersion;

/// fetch device version
+ (NSString *)bridgeDeviceVersion:(int)deviceId;

/// fetch seraill number
+ (NSString *)bridgeSerialNumber:(int)deviceId;



+ (UIImage *)imageForData:(uint32_t *)list;


/// unregister block
+ (int)bridgeUnregisterBlock;

/// ethernet reconnect
+ (int)bridgeEthernetReconenction:(int)deviceId;

@end
