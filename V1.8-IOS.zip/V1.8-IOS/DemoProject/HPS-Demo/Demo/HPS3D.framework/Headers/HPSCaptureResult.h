//
//  HPSCaptureResult.h
//  HPS3D
//
//  Created by 修齐 on 2023/3/11.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPSCaptureResult : NSObject

@property (nonatomic, strong) UIImage *image;
@property (nonatomic, assign) int distance_average;     /*整个视野有效距离的平均值*/
@property (nonatomic, assign) int distance_min;         /*最小距离估算值*/
@property (nonatomic, assign) int saturation_count;     /*饱和像素点数*/

@property (nonatomic, assign) int roi_num;              /*被激活的ROI总数*/
@property (nonatomic, assign) int roi_id;               /*ROI ID号*/
@property (nonatomic, assign) int group_id;             /*ROI组 ID号*/
@property (nonatomic, assign) int threshold_state;      /*报警状态指示位,bit0:阈值0报警, bit1:阈值1报警, bit2:阈值2报警*/

@end

NS_ASSUME_NONNULL_END
