//
//  HPS3D.h
//  HPS3D
//
//  Created by 修齐 on 2023/3/2.
//

#import <Foundation/Foundation.h>

//! Project version number for HPS3D.
FOUNDATION_EXPORT double HPS3DVersionNumber;

//! Project version string for HPS3D.
FOUNDATION_EXPORT const unsigned char HPS3DVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HPS3D/PublicHeader.h>

#import <HPS3D/HPSBridge.h>
#import <HPS3D/HPSSetting.h>
#import <HPS3D/HPSCaptureResult.h>
