//
//  HPSSetting.h
//  HPS3D
//
//  Created by 修齐 on 2023/3/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HPSSetting : NSObject

@property (nonatomic, assign) int user_id;              /*用户自定义ID，默认为0*/
@property (nonatomic, assign) int max_resolution_X;     /*X方向分辨率，默认160*/
@property (nonatomic, assign) int max_resolution_Y;     /*Y方向分辨率，默认60*/
@property (nonatomic, assign) int max_roi_group_number; /*支持的最大ROI分组数，默认为16*/
@property (nonatomic, assign) int max_roi_number;       /*支持的最大ROI数，默认为8*/
@property (nonatomic, assign) int max_threshold_number; /*支持的最大阈值报警数，默认为3*/
@property (nonatomic, assign) int max_multiCamera_code; /*支持的最大多机编号，默认为16*/
@property (nonatomic, assign) int dist_filter_enable;   /*距离滤波器开启状态，默认为false*/
@property (nonatomic, assign) float dist_filter_K;      /*距离滤波器比例系数*/
@property (nonatomic, assign) int smooth_filter_type;   /*平滑滤波器类型*/
@property (nonatomic, assign) int smooth_filter_args;   /*平滑滤波器参数*/
@property (nonatomic, assign) int cur_group_id;         /*当前ROI分组*/
@property (nonatomic, assign) int cur_multiCamera_code; /*当前多机编号*/
@property (nonatomic, assign) int dist_offset;          /*当前多机编号*/
@property (nonatomic, assign) int optical_path_calibration; /*光程补偿开启状态*/
@property (nonatomic, assign) int edge_filter_enable;   /*边缘滤波开启状态*/

@end

@interface HPSLocation : NSObject

@property (nonatomic, assign) int locationx;
@property (nonatomic, assign) int locationy;
@property (nonatomic, assign) int locationz;

- (BOOL)isNone;

@end

NS_ASSUME_NONNULL_END
