//
//  HomeVC.swift
//  HPS3DDemo
//
//  Created by 修齐 on 2023/3/2.
//

import UIKit
import SnapKit
import HPS3D
import BRPickerView
import Toast

class HomeVC: UIViewController {
    
    private var deviceId: Int32 = -1
    
    private lazy var usbBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.setTitle(" USB", for: .normal)
        bn.addTarget(self, action: #selector(chooseUSB), for: .touchUpInside)
        bn.setImage(UIImage(named: "check_off"), for: .normal)
        bn.setImage(UIImage(named: "check_on"), for: .selected)
        bn.contentHorizontalAlignment = .left
        bn.isHidden = true
        return bn
    }()
    
    private lazy var ethBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.setTitle(" Ethernet", for: .normal)
        bn.addTarget(self, action: #selector(chooseNet), for: .touchUpInside)
        bn.setImage(UIImage(named: "check_off"), for: .normal)
        bn.setImage(UIImage(named: "check_on"), for: .selected)
        bn.contentHorizontalAlignment = .left
        bn.isSelected = true
        return bn
    }()
    
    private lazy var ipField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.text = "192.168.1.193"
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var portField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.text = "12345"
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var connectBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("Connect", for: .normal)
        bn.addTarget(self, action: #selector(connectAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var disConnectBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("DisConnect", for: .normal)
        bn.addTarget(self, action: #selector(disConnectAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var continuousBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("Continuous", for: .normal)
        bn.addTarget(self, action: #selector(continuousAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var singleBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("Single", for: .normal)
        bn.addTarget(self, action: #selector(singleAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var userIdField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var userIdBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("SetUserID", for: .normal)
        bn.addTarget(self, action: #selector(userIdAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var cameraCodeField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    private lazy var camaraCodeChooseBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.addTarget(self, action: #selector(chooseCameraCodeAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var cameraCodeBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("setCameraCode", for: .normal)
        bn.addTarget(self, action: #selector(cameraCodeAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var groupIdField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    private lazy var groupIdChooseBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.addTarget(self, action: #selector(groupIdChooseAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var groupIdBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("SetGroupID", for: .normal)
        bn.addTarget(self, action: #selector(groupIdAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var distSetField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var distOffSetBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("SetDistOffSet", for: .normal)
        bn.addTarget(self, action: #selector(distOffSetAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var distanceFilterField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    private lazy var distanceFilterChooseBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.setTitle("disable", for: .normal)
        bn.setTitle("enable", for: .selected)
        bn.layer.cornerRadius = 4
        bn.layer.borderColor = UIColor.lightGray.cgColor
        bn.layer.borderWidth = 1
        bn.addTarget(self, action: #selector(distanceFilterChooseAction), for: .touchUpInside)
        bn.isSelected = false
        return bn
    }()
    
    private lazy var distanceFilterBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("SetDistanceFilter", for: .normal)
        bn.addTarget(self, action: #selector(distanceFilterAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var smoothFilterField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var smoothFilterChooseBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 4
        bn.layer.borderColor = UIColor.lightGray.cgColor
        bn.layer.borderWidth = 1
        bn.addTarget(self, action: #selector(smoothFilterChooseAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var smoothFilterChooseValueBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.addTarget(self, action: #selector(smoothFilterChooseValueAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var smoothBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("SetSmoothFilter", for: .normal)
        bn.addTarget(self, action: #selector(smoothAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var opticalPathCalField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var opticalPathCalChooseBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.addTarget(self, action: #selector(opticalPathCalChooseAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var opticalBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("SetOpticalPathCalibration", for: .normal)
        bn.addTarget(self, action: #selector(opticalAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var exportBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("ExportSettings", for: .normal)
        bn.addTarget(self, action: #selector(exportAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var saveSetBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 13), color: .black)
        bn.layer.cornerRadius = 3
        bn.layer.borderWidth = 1
        bn.layer.borderColor = UIColor.black.cgColor
        bn.clipsToBounds = true
        bn.setTitle("SaveSettings", for: .normal)
        bn.addTarget(self, action: #selector(saveSetAction), for: .touchUpInside)
        return bn
    }()
    
    private lazy var avgField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var minField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var satField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var roinumField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var selroiField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var groupidField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var roiidField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var statusField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var inputXField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var inputYField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        return field
    }()
    
    private lazy var resultOneField: UITextField = {
        let field = UITextField(frame: .zero)
        field.borderStyle = .roundedRect
        field.layer.borderWidth = 0
        field.font = .systemFont(ofSize: 13)
        field.backgroundColor = .lightText
        field.isEnabled = false
        return field
    }()
    
    private lazy var statusLb: UILabel = {
        let lb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        return lb
    }()
    
    private lazy var verLb: UILabel = {
        let lb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        return lb
    }()
    
    private lazy var devVerLb: UILabel = {
        let lb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        return lb
    }()
    
    private lazy var snLb: UILabel = {
        let lb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        return lb
    }()
    
    private lazy var locationBn: UIButton = {
        let bn = UIButton.button(font: .systemFont(ofSize: 16), color: .white)
        bn.setTitle("+", for: .normal)
        return bn
    }()
    
    private var setting: HPSSetting = HPSSetting()
    
    private lazy var img: UIImageView = {
        let img = UIImageView(frame: .zero)
        img.contentMode = .scaleAspectFill
        img.backgroundColor = UIColor.white // UIColor(hexString: "000000")
        img.clipsToBounds = true
        return img
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        configView()
        
        HPSManager.shared.block = { [weak self] value, index in
            DispatchQueue.main.async {
                self?.updateResult(value, index)
            }
        }
    }
    
    private func updateResult(_ sender: HPSCaptureResult, _ location: HPSLocation) {
        img.image = sender.image
        avgField.text = "\(sender.distance_average)"
        minField.text = "\(sender.distance_min)"
        satField.text = "\(sender.saturation_count)"
        roinumField.text = "\(sender.roi_num)"
        statusField.text = "\(sender.threshold_state)"
        groupidField.text = "\(sender.group_id)"
        roiidField.text = "\(sender.roi_id)"
        
        if !location.isNone() {
            resultOneField.text = "{x: \(location.locationx) y: \(location.locationy), z: \(location.locationz)}"
        }
    }
    
    @objc private func chooseUSB() {
        usbBn.isSelected = true
        ethBn.isSelected = false
    }
    
    @objc private func chooseNet() {
        ethBn.isSelected = true
        usbBn.isSelected = false
    }
    
    @objc private func connectAction() {
        let port = (portField.text ?? "").trimSpace
        if port.isEmpty {
            return
        }
        
        var result: Int32 = 0
        if usbBn.isSelected {
            result = HPSManager.usbConnect(deviceId: &deviceId, port: port)
        } else if ethBn.isSelected {
            let ip = (ipField.text ?? "").trimSpace
            if ip.isEmpty {
                return
            }
            result = HPSManager.ethernetConnect(ip: ip, port: port, deviceId: &deviceId)
        }
        if result == 1 {
            view.makeToast("Connect Successfully")
            // 获取信息
            fetchSDKInfo()
            // 注册回调
            HPSManager.shared.register()
            // 获取配置内容
            _ = HPSManager.exportSetting(deviceId: deviceId) { [weak self] value in
                self?.setting = value
                self?.updateView()
            }
        } else {
            view.makeToast("Connect failed with code = \(result)")
        }
    }
    private func updateView() {
        userIdField.text = "\(setting.user_id)"
        cameraCodeField.text = "\(setting.cur_multiCamera_code)"
        groupIdField.text = "\(setting.cur_group_id)"
        distSetField.text = "\(setting.dist_offset)"
        distanceFilterChooseBn.isSelected = setting.dist_filter_enable == 1
        distanceFilterField.text = "\(setting.dist_filter_K)"
        smoothFilterChooseBn.setTitle("\(setting.smooth_filter_type)", for: .normal)
        smoothFilterField.text = "\(setting.smooth_filter_args)"
        opticalPathCalField.text = "\(setting.optical_path_calibration)"
        selroiField.text = "\(setting.max_roi_number)"
    }
    
    @objc private func disConnectAction() {
        let result = HPSManager.disConnect(deviceId: deviceId)
        if result == 1 {
            view.makeToast("DisConnect Successfully")
            fetchSDKInfo()
            deviceId = -1
        } else {
            view.makeToast("DisConnect failed with code = \(result)")
        }
    }
    
    @objc private func continuousAction() {
        if deviceId != -1 {
            if HPSManager.captureIsStarted(deviceId) {
                let result = HPSManager.stopCapture(deviceId)
                if result == 1 {
                    view.makeToast("Success")
                } else {
                    view.makeToast("Failed with code = \(result)")
                }
            } else {
                let result = HPSManager.shared.startCapture(deviceId: deviceId)
                if result == 1 {
                    view.makeToast("Success")
                } else {
                    view.makeToast("Failed with code = \(result)")
                }
            }
        }
    }
    
    @objc private func singleAction() {
        if deviceId != -1 {
            let result = HPSManager.singleCapture(deviceId: deviceId) { [weak self] value in
                self?.updateResult(value, HPSLocation())
            }
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func userIdAction() {
        let userId = userIdField.text ?? ""
        if deviceId != -1, !userId.isEmpty, let user = Int(userId), user < 256 {
            let result = HPSManager.setUserId(deviceId: deviceId, userId: user)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func cameraCodeAction() {
        let camereCode = cameraCodeField.text ?? ""
        if deviceId != -1, !camereCode.isEmpty, let code = Int(camereCode), code < 16 {
            let result = HPSManager.setCameraCode(deviceId: deviceId, code: code)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func groupIdAction() {
        let groupIdInfo = groupIdField.text ?? ""
        if deviceId != -1, !groupIdInfo.isEmpty, let groupId = Int(groupIdInfo), groupId < 16 {
            let result = HPSManager.setGroupId(deviceId: deviceId, groupId: groupId)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func distOffSetAction() {
        let offsetInfo = distSetField.text ?? ""
        if deviceId != -1, !offsetInfo.isEmpty, let offset = Int(offsetInfo), offset < 5000 {
            let result = HPSManager.setDistanceOffset(deviceId: deviceId, offset: offset)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func distanceFilterAction() {
        let filterInfo = distanceFilterField.text ?? ""
        if deviceId != -1, !filterInfo.isEmpty, let offset = Float(filterInfo), offset < 1 {
            let result = HPSManager.setDistanceFilter(deviceId: deviceId, enable: distanceFilterChooseBn.isSelected, filter: offset)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func smoothAction() {
        let smoothInfo = smoothFilterField.text ?? ""
        let typeInfo = smoothFilterChooseBn.titleLabel?.text ?? ""
        let type = Int(typeInfo) ?? 0
        if deviceId != -1, !smoothInfo.isEmpty, let filter = Int(smoothInfo) {
            let result = HPSManager.setSmoothFilter(deviceId: deviceId, type: type, filter: filter)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func opticalAction() {
        let enable: Bool = false
        if deviceId != -1 {
            let result = HPSManager.setOpticalPathCal(deviceId: deviceId, enable: enable)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func exportAction() {
        if deviceId != -1 {
            let result = HPSManager.exportSetting(deviceId: deviceId) { [weak self] value in
                self?.setting = value
                self?.updateView()
            }
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    @objc private func saveSetAction() {
        if deviceId != -1 {
            let result = HPSManager.saveSetting(deviceId: deviceId)
            if result == 1 {
                view.makeToast("Success")
            } else {
                view.makeToast("Failed with code = \(result)")
            }
        }
    }
    
    private func fetchSDKInfo() {
        statusLb.text = HPSManager.isConnect(deviceId: deviceId) ? "Connected" : "DisConnected"
        statusLb.textColor = HPSManager.isConnect(deviceId: deviceId) ? UIColor.green : UIColor.red
        verLb.text = HPSManager.sdkVersion()
        devVerLb.text = HPSManager.deviceVersion(deviceId: deviceId)
        snLb.text = HPSManager.serialNumber(deviceId: deviceId)
    }
}

extension HomeVC {
    @objc private func chooseCameraCodeAction() {
        var numList: [Int] = []
        for i in 0..<setting.max_multiCamera_code {
            numList.append(Int(i))
        }
        let results: [BRResultModel] = numList.map { sub -> BRResultModel in
            let model = BRResultModel()
            model.key = "\(sub)"
            model.value = "\(sub)"
            return model
        }
        let pickerView = BRStringPickerView()
        pickerView.pickerMode = .componentSingle
        pickerView.dataSourceArr = results
        pickerView.resultModelBlock = { [weak self] value in
            self?.cameraCodeField.text = value?.key
        }
        pickerView.show()
    }
    
    @objc private func groupIdChooseAction() {
        var numList: [Int] = []
        for i in 0..<setting.max_roi_group_number {
            numList.append(Int(i))
        }
        let results: [BRResultModel] = numList.map { sub -> BRResultModel in
            let model = BRResultModel()
            model.key = "\(sub)"
            model.value = "\(sub)"
            return model
        }
        let pickerView = BRStringPickerView()
        pickerView.pickerMode = .componentSingle
        pickerView.dataSourceArr = results
        pickerView.resultModelBlock = { [weak self] value in
            self?.groupIdField.text = value?.key
        }
        pickerView.show()
    }
    
    @objc private func distanceFilterChooseAction() {
        let results: [BRResultModel] = [0, 1].map { sub -> BRResultModel in
            let model = BRResultModel()
            model.key = "\(sub)"
            model.value = sub == 0 ? "disable" : "enable"
            return model
        }
        let pickerView = BRStringPickerView()
        pickerView.pickerMode = .componentSingle
        pickerView.dataSourceArr = results
        pickerView.resultModelBlock = { [weak self] value in
            self?.distanceFilterChooseBn.isSelected = value?.key == "1"
        }
        pickerView.show()
    }
    
    @objc private func smoothFilterChooseAction() {
        let results: [BRResultModel] = [0, 1, 2].map { sub -> BRResultModel in
            let model = BRResultModel()
            model.key = "\(sub)"
            if sub == 0 {
                model.value = "disable"
            } else if sub == 1 {
                model.value = "average filter"
            } else if sub == 2 {
                model.value = "guass filter"
            }
            return model
        }
        let pickerView = BRStringPickerView()
        pickerView.pickerMode = .componentSingle
        pickerView.dataSourceArr = results
        pickerView.resultModelBlock = { [weak self] value in
            self?.smoothFilterChooseBn.setTitle(value?.key, for: .normal)
        }
        pickerView.show()
    }
    
    @objc private func smoothFilterChooseValueAction() {
        let results: [BRResultModel] = [2, 3].map { sub -> BRResultModel in
            let model = BRResultModel()
            model.key = "\(sub)"
            model.value = "\(sub)"
            return model
        }
        let pickerView = BRStringPickerView()
        pickerView.pickerMode = .componentSingle
        pickerView.dataSourceArr = results
        pickerView.resultModelBlock = { [weak self] value in
            self?.smoothFilterField.text = value?.key
        }
        pickerView.show()
    }
    
    @objc private func opticalPathCalChooseAction() {
        let results: [BRResultModel] = [0, 1].map { sub -> BRResultModel in
            let model = BRResultModel()
            model.key = "\(sub)"
            model.value = "\(sub)"
            return model
        }
        let pickerView = BRStringPickerView()
        pickerView.pickerMode = .componentSingle
        pickerView.dataSourceArr = results
        pickerView.resultModelBlock = { [weak self] value in
            self?.opticalPathCalField.text = value?.key
        }
        pickerView.show()
    }
    
    @objc private func submitAction() {
        let inputx: Int = Int(inputXField.text ?? "0") ?? 0
        let inputy: Int = Int(inputYField.text ?? "0") ?? 0
        if inputx < 160, inputy < 60 {
            let width: CGFloat = UIScreen.main.bounds.width - 270
            let scale: CGFloat = width / 160.0
            locationBn.snp.remakeConstraints { make in
                make.center.equalTo(CGPoint(x: CGFloat(inputx) * scale, y: CGFloat(inputy) * scale))
                make.width.height.equalTo(20)
            }
            HPSManager.locationInBitMap(locationX: inputx, locationY: inputy)
        } else {
            view.makeToast("数据越界")
        }
        
    }
}

extension HomeVC {
    private func configView() {
        view.backgroundColor = .white
        
        let connectView = UIView(frame: .zero)
        connectView.backgroundColor = UIColor(hexString: "#F5F6F8")
        connectView.layer.cornerRadius = 4
        connectView.clipsToBounds = true
        view.addSubview(connectView)
        connectView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(10)
            make.width.equalTo(240)
            make.height.equalTo(200)
        }
        
        let titleLb1 = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        titleLb1.text = "Communication Settings"
        connectView.addSubview(titleLb1)
        titleLb1.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(16)
        }
        
        connectView.addSubview(ethBn)
        ethBn.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(titleLb1.snp.bottom).offset(10)
            make.height.equalTo(25)
            make.width.equalTo(90)
        }
        
        connectView.addSubview(usbBn)
        usbBn.snp.makeConstraints { make in
            make.left.equalTo(ethBn.snp.right).offset(20)
            make.top.equalTo(ethBn.snp.top)
            make.height.equalTo(25)
            make.width.equalTo(90)
        }
        
        let ipTitle = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        ipTitle.text = "IP"
        connectView.addSubview(ipTitle)
        ipTitle.snp.makeConstraints { make in
            make.top.equalTo(ethBn.snp.bottom).offset(15)
            make.left.equalTo(ethBn.snp.left)
        }
        connectView.addSubview(ipField)
        ipField.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(50)
            make.centerY.equalTo(ipTitle.snp.centerY)
            make.right.equalTo(usbBn.snp.right)
            make.height.equalTo(26)
        }
        
        let portTitle = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        portTitle.text = "Port"
        connectView.addSubview(portTitle)
        portTitle.snp.makeConstraints { make in
            make.top.equalTo(ipTitle.snp.bottom).offset(15)
            make.left.equalTo(ethBn.snp.left)
        }
        
        connectView.addSubview(portField)
        portField.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(50)
            make.centerY.equalTo(portTitle.snp.centerY)
            make.right.equalTo(usbBn.snp.right)
            make.height.equalTo(26)
        }
        
        connectView.addSubview(connectBn)
        connectBn.snp.makeConstraints { make in
            make.top.equalTo(portTitle.snp.bottom).offset(20)
            make.left.equalTo(ethBn.snp.left)
            make.width.equalTo(90)
            make.height.equalTo(30)
        }
        
        connectView.addSubview(disConnectBn)
        disConnectBn.snp.makeConstraints { make in
            make.top.equalTo(portTitle.snp.bottom).offset(20)
            make.left.equalTo(usbBn.snp.left)
            make.width.equalTo(90)
            make.height.equalTo(30)
        }
        
        // Capture Mode
        let captureView = UIView(frame: .zero)
        captureView.backgroundColor = UIColor(hexString: "#F5F6F8")
        captureView.layer.cornerRadius = 4
        captureView.clipsToBounds = true
        view.addSubview(captureView)
        captureView.snp.makeConstraints { make in
            make.top.equalTo(connectView.snp.bottom).offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.equalTo(240)
            make.height.equalTo(120)
        }
        
        let captureLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        captureView.addSubview(captureLb)
        captureLb.text = "Capture Mode"
        captureLb.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(16)
        }
        
        captureView.addSubview(continuousBn)
        continuousBn.snp.makeConstraints { make in
            make.top.equalTo(captureLb.snp.bottom).offset(20)
            make.left.equalTo(ethBn.snp.left)
            make.width.equalTo(90)
            make.height.equalTo(30)
        }
        
        captureView.addSubview(singleBn)
        singleBn.snp.makeConstraints { make in
            make.top.equalTo(captureLb.snp.bottom).offset(20)
            make.left.equalTo(usbBn.snp.left)
            make.width.equalTo(90)
            make.height.equalTo(30)
        }
        
        // Advance Settings
        let advanceSetView = UIView(frame: .zero)
        advanceSetView.backgroundColor = UIColor(hexString: "#F5F6F8")
        advanceSetView.layer.cornerRadius = 4
        advanceSetView.clipsToBounds = true
        view.addSubview(advanceSetView)
        advanceSetView.snp.makeConstraints { make in
            make.top.equalTo(captureView.snp.bottom).offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.equalTo(500)
            make.height.equalTo(360)
        }
        
        let advanceLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        advanceSetView.addSubview(advanceLb)
        advanceLb.text = "Advance Settings"
        advanceLb.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(16)
        }
        
        let userIdLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        userIdLb.text = "UserID"
        advanceSetView.addSubview(userIdLb)
        userIdLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(advanceLb.snp.bottom).offset(20)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(userIdField)
        userIdField.snp.makeConstraints { make in
            make.centerY.equalTo(userIdLb.snp.centerY)
            make.left.equalToSuperview().offset(120)
            make.width.equalTo(120)
            make.height.equalTo(26)
        }
        
        let camerCodeLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        camerCodeLb.text = "CameraCode"
        advanceSetView.addSubview(camerCodeLb)
        camerCodeLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(userIdLb.snp.bottom).offset(5)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(cameraCodeField)
        cameraCodeField.snp.makeConstraints { make in
            make.centerY.equalTo(camerCodeLb.snp.centerY)
            make.left.equalToSuperview().offset(120)
            make.width.equalTo(120)
            make.height.equalTo(26)
        }
        advanceSetView.addSubview(camaraCodeChooseBn)
        camaraCodeChooseBn.snp.makeConstraints { make in
            make.edges.equalTo(cameraCodeField)
        }
        
        let groupIdLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        groupIdLb.text = "GroupID"
        advanceSetView.addSubview(groupIdLb)
        groupIdLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(camerCodeLb.snp.bottom).offset(5)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(groupIdField)
        groupIdField.snp.makeConstraints { make in
            make.centerY.equalTo(groupIdLb.snp.centerY)
            make.left.equalToSuperview().offset(120)
            make.width.equalTo(120)
            make.height.equalTo(26)
        }
        advanceSetView.addSubview(groupIdChooseBn)
        groupIdChooseBn.snp.makeConstraints { make in
            make.edges.equalTo(groupIdField)
        }
        
        let distSetLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        distSetLb.text = "DistOffSet"
        advanceSetView.addSubview(distSetLb)
        distSetLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(groupIdLb.snp.bottom).offset(5)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(distSetField)
        distSetField.snp.makeConstraints { make in
            make.centerY.equalTo(distSetLb.snp.centerY)
            make.left.equalToSuperview().offset(120)
            make.width.equalTo(120)
            make.height.equalTo(26)
        }
        
        let distFilterLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        distFilterLb.text = "DistanceFilter"
        advanceSetView.addSubview(distFilterLb)
        distFilterLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(distSetLb.snp.bottom).offset(5)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(distanceFilterChooseBn)
        distanceFilterChooseBn.snp.makeConstraints { make in
            make.centerY.equalTo(distFilterLb.snp.centerY)
            make.left.equalToSuperview().offset(120)
            make.width.equalTo(120)
            make.height.equalTo(26)
        }
        
        let smoothLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        smoothLb.text = "SmoothFilter"
        advanceSetView.addSubview(smoothLb)
        smoothLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(distFilterLb.snp.bottom).offset(5)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(smoothFilterChooseBn)
        smoothFilterChooseBn.snp.makeConstraints { make in
            make.centerY.equalTo(smoothLb.snp.centerY)
            make.left.equalToSuperview().offset(120)
            make.width.equalTo(120)
            make.height.equalTo(26)
        }
        
        let pathCalLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        pathCalLb.text = "OptiocalPathCal"
        advanceSetView.addSubview(pathCalLb)
        pathCalLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(smoothLb.snp.bottom).offset(5)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(opticalPathCalField)
        opticalPathCalField.snp.makeConstraints { make in
            make.centerY.equalTo(pathCalLb.snp.centerY)
            make.left.equalToSuperview().offset(120)
            make.width.equalTo(120)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(opticalPathCalChooseBn)
        opticalPathCalChooseBn.snp.makeConstraints { make in
            make.edges.equalTo(opticalPathCalField)
        }
        
        advanceSetView.addSubview(exportBn)
        exportBn.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.right.equalTo(opticalPathCalField.snp.right)
            make.top.equalTo(opticalPathCalField.snp.bottom).offset(10)
            make.height.equalTo(30)
        }
        
        advanceSetView.addSubview(userIdBn)
        userIdBn.snp.makeConstraints { make in
            make.left.equalTo(userIdField.snp.right).offset(10)
            make.centerY.equalTo(userIdField.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(cameraCodeBn)
        cameraCodeBn.snp.makeConstraints { make in
            make.left.equalTo(cameraCodeField.snp.right).offset(10)
            make.centerY.equalTo(cameraCodeField.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(groupIdBn)
        groupIdBn.snp.makeConstraints { make in
            make.left.equalTo(groupIdField.snp.right).offset(10)
            make.centerY.equalTo(groupIdField.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(distOffSetBn)
        distOffSetBn.snp.makeConstraints { make in
            make.left.equalTo(distSetField.snp.right).offset(10)
            make.centerY.equalTo(distSetField.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(distanceFilterField)
        distanceFilterField.snp.makeConstraints { make in
            make.left.equalTo(distanceFilterChooseBn.snp.right).offset(10)
            make.centerY.equalTo(distanceFilterChooseBn.snp.centerY)
            make.width.equalTo(50)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(distanceFilterBn)
        distanceFilterBn.snp.makeConstraints { make in
            make.left.equalTo(distanceFilterField.snp.right).offset(10)
            make.centerY.equalTo(distanceFilterField.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(smoothFilterField)
        smoothFilterField.snp.makeConstraints { make in
            make.left.equalTo(smoothFilterChooseBn.snp.right).offset(10)
            make.centerY.equalTo(smoothFilterChooseBn.snp.centerY)
            make.width.equalTo(50)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(smoothFilterChooseValueBn)
        smoothFilterChooseValueBn.snp.makeConstraints { make in
            make.edges.equalTo(smoothFilterField)
        }
        
        advanceSetView.addSubview(smoothBn)
        smoothBn.snp.makeConstraints { make in
            make.left.equalTo(smoothFilterField.snp.right).offset(10)
            make.centerY.equalTo(smoothFilterField.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(opticalBn)
        opticalBn.snp.makeConstraints { make in
            make.left.equalTo(opticalPathCalField.snp.right).offset(10)
            make.centerY.equalTo(opticalPathCalField.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        advanceSetView.addSubview(saveSetBn)
        saveSetBn.snp.makeConstraints { make in
            make.left.equalTo(exportBn.snp.right).offset(10)
            make.centerY.equalTo(exportBn.snp.centerY)
            make.width.equalTo(170)
            make.height.equalTo(26)
        }
        
        // measure view
        let measureView = UIView(frame: .zero)
        measureView.backgroundColor = UIColor(hexString: "#F5F6F8")
        measureView.layer.cornerRadius = 4
        measureView.clipsToBounds = true
        view.addSubview(measureView)
        
        measureView.snp.makeConstraints { make in
            make.top.equalTo(advanceSetView.snp.top)
            make.left.equalTo(advanceSetView.snp.right).offset(10)
            make.right.equalToSuperview().offset(-10)
            make.height.equalTo(advanceSetView.snp.height)
        }
        
        let measureLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        measureView.addSubview(measureLb)
        measureLb.text = "Measure Data"
        measureLb.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(16)
        }
        
        let avgLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        avgLb.text = "AvgDist"
        measureView.addSubview(avgLb)
        avgLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(measureLb.snp.bottom).offset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
        
        measureView.addSubview(avgField)
        avgField.snp.makeConstraints { make in
            make.centerY.equalTo(avgLb.snp.centerY)
            make.left.equalTo(avgLb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }

        let minLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        minLb.text = "MinDist"
        measureView.addSubview(minLb)
        minLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(avgLb.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
        
        measureView.addSubview(minField)
        minField.snp.makeConstraints { make in
            make.centerY.equalTo(minLb.snp.centerY)
            make.left.equalTo(minLb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }
        
        let satLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        satLb.text = "SatCnt"
        measureView.addSubview(satLb)
        satLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(minLb.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
        
        measureView.addSubview(satField)
        satField.snp.makeConstraints { make in
            make.centerY.equalTo(satLb.snp.centerY)
            make.left.equalTo(satLb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }
        
        let roinumLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        roinumLb.text = "RoiNum"
        measureView.addSubview(roinumLb)
        roinumLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(satLb.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
        
        measureView.addSubview(roinumField)
        roinumField.snp.makeConstraints { make in
            make.centerY.equalTo(roinumLb.snp.centerY)
            make.left.equalTo(roinumLb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }
        
        let selroiLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        selroiLb.text = "SelRoi"
        measureView.addSubview(selroiLb)
        selroiLb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(roinumLb.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
        
        measureView.addSubview(selroiField)
        selroiField.snp.makeConstraints { make in
            make.centerY.equalTo(selroiLb.snp.centerY)
            make.left.equalTo(selroiLb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }
        
        let groupidlb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        groupidlb.text = "GroupID"
        measureView.addSubview(groupidlb)
        groupidlb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(selroiLb.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(52)
        }
        
        measureView.addSubview(groupidField)
        groupidField.snp.makeConstraints { make in
            make.centerY.equalTo(groupidlb.snp.centerY)
            make.left.equalTo(groupidlb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }
        
        let roilb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        roilb.text = "RoiID"
        measureView.addSubview(roilb)
        roilb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(groupidlb.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
        
        measureView.addSubview(roiidField)
        roiidField.snp.makeConstraints { make in
            make.centerY.equalTo(roilb.snp.centerY)
            make.left.equalTo(roilb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }
        
        let statuslb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        statuslb.text = "Status"
        measureView.addSubview(statuslb)
        statuslb.snp.makeConstraints { make in
            make.left.equalToSuperview().offset(16)
            make.top.equalTo(roilb.snp.bottom).offset(5)
            make.height.equalTo(30)
            make.width.equalTo(50)
        }
        
        measureView.addSubview(statusField)
        statusField.snp.makeConstraints { make in
            make.centerY.equalTo(statuslb.snp.centerY)
            make.left.equalTo(statuslb.snp.right).offset(10)
            make.right.equalToSuperview().offset(-40)
            make.height.equalTo(26)
        }
        
        // info view
        let infoView = UIView(frame: .zero)
        infoView.backgroundColor = UIColor(hexString: "#F5F6F8")
        infoView.layer.cornerRadius = 4
        infoView.clipsToBounds = true
        view.addSubview(infoView)
        infoView.snp.makeConstraints { make in
            make.top.equalTo(advanceSetView.snp.bottom).offset(10)
            make.left.equalToSuperview().offset(10)
            make.width.equalTo(440)
            make.height.equalTo(120)
        }
        
        let infoLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        infoView.addSubview(infoLb)
        infoLb.text = "Info"
        infoLb.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(16)
        }
        
        let connectLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        connectLb.text = "Status："
        infoView.addSubview(connectLb)
        connectLb.snp.makeConstraints { make in
            make.top.equalTo(infoLb.snp.bottom).offset(10)
            make.left.equalToSuperview().offset(16)
        }
        
        infoView.addSubview(statusLb)
        statusLb.snp.makeConstraints { make in
            make.left.equalTo(connectLb.snp.right).offset(4)
            make.centerY.equalTo(connectLb.snp.centerY)
        }
        
        let sdkLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        sdkLb.text = "SDK Ver："
        infoView.addSubview(sdkLb)
        sdkLb.snp.makeConstraints { make in
            make.top.equalTo(infoLb.snp.bottom).offset(10)
            make.left.equalToSuperview().offset(186)
        }
        
        infoView.addSubview(verLb)
        verLb.snp.makeConstraints { make in
            make.left.equalTo(sdkLb.snp.right).offset(4)
            make.centerY.equalTo(connectLb.snp.centerY)
        }
        
        let devLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        devLb.text = "DEV Ver："
        infoView.addSubview(devLb)
        devLb.snp.makeConstraints { make in
            make.top.equalTo(infoLb.snp.bottom).offset(35)
            make.left.equalToSuperview().offset(16)
        }
        
        infoView.addSubview(devVerLb)
        devVerLb.snp.makeConstraints { make in
            make.left.equalTo(devLb.snp.right).offset(4)
            make.centerY.equalTo(devLb.snp.centerY)
        }
        
        let snHintLb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        snHintLb.text = "SN："
        infoView.addSubview(snHintLb)
        snHintLb.snp.makeConstraints { make in
            make.top.equalTo(infoLb.snp.bottom).offset(35)
            make.left.equalToSuperview().offset(186)
        }

        infoView.addSubview(snLb)
        snLb.snp.makeConstraints { make in
            make.left.equalTo(snHintLb.snp.right).offset(4)
            make.centerY.equalTo(snHintLb.snp.centerY)
        }
        
        view.addSubview(img)
        img.snp.makeConstraints { make in
            make.top.equalTo(connectView.snp.top)
            make.left.equalTo(connectView.snp.right).offset(10)
            make.height.equalTo(img.snp.width).multipliedBy(60.0 / 160)
            make.right.equalToSuperview().offset(-10)
        }
        
        img.addSubview(locationBn)
        locationBn.snp.makeConstraints { make in
            make.center.equalTo(CGPoint.zero)
            make.width.height.equalTo(10)
        }
        
        let inputXlb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        inputXlb.text = "input X (0-160)："
        view.addSubview(inputXlb)
        inputXlb.snp.makeConstraints { make in
            make.top.equalTo(img.snp.bottom).offset(20)
            make.left.equalTo(img.snp.left)
            make.height.equalTo(30)
        }
        
        view.addSubview(inputXField)
        inputXField.snp.makeConstraints { make in
            make.centerY.equalTo(inputXlb.snp.centerY)
            make.width.equalTo(80)
            make.height.equalTo(26)
            make.left.equalTo(inputXlb.snp.right).offset(4)
        }
        
        let inputYlb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        inputYlb.text = "input Y (0-60)："
        view.addSubview(inputYlb)
        inputYlb.snp.makeConstraints { make in
            make.top.equalTo(img.snp.bottom).offset(20)
            make.left.equalTo(inputXField.snp.right).offset(10)
            make.height.equalTo(30)
        }
        
        view.addSubview(inputYField)
        inputYField.snp.makeConstraints { make in
            make.centerY.equalTo(inputYlb.snp.centerY)
            make.width.equalTo(80)
            make.height.equalTo(26)
            make.left.equalTo(inputYlb.snp.right).offset(4)
        }
        
        let submitBn = UIButton.button(font: .systemFont(ofSize: 13), color: .white, background: .black)
        submitBn.setTitle("Submit", for: .normal)
        submitBn.layer.cornerRadius = 4
        submitBn.addTarget(self, action: #selector(submitAction), for: .touchUpInside)
        view.addSubview(submitBn)
        submitBn.snp.makeConstraints { make in
            make.centerY.equalTo(inputXField.snp.centerY)
            make.left.equalTo(inputYField.snp.right).offset(10)
            make.width.equalTo(100)
            make.height.equalTo(28)
        }
        
        let resultOnelb = UILabel.label(font: .systemFont(ofSize: 13), color: .black)
        resultOnelb.text = "resultOne:"
        view.addSubview(resultOnelb)
        resultOnelb.snp.makeConstraints { make in
            make.top.equalTo(submitBn.snp.bottom).offset(20)
            make.left.equalTo(img.snp.left)
            make.height.equalTo(30)
        }
        
        view.addSubview(resultOneField)
        resultOneField.snp.makeConstraints { make in
            make.left.equalTo(resultOnelb.snp.right).offset(10)
            make.centerY.equalTo(resultOnelb.snp.centerY)
            make.width.equalTo(200)
            make.height.equalTo(30)
        }
        
    }
}

extension UILabel {
    public class func label(font: UIFont, color: UIColor, background: UIColor = .clear) -> UILabel {
        let lb = UILabel(frame: .zero)
        lb.textColor = color
        lb.font = font
        lb.backgroundColor = background
        return lb
    }
}

extension UIButton {
    
    public class func button(font: UIFont, color: UIColor, background: UIColor = .clear) -> UIButton {
        let bn = UIButton(frame: .zero)
        bn.setTitleColor(color, for: .normal)
        bn.titleLabel?.font = font
        bn.backgroundColor = background
        return bn
    }
}

extension String {
    
    var trimSpace:String {
        let whitespace = NSCharacterSet.whitespaces
        return self.trimmingCharacters(in: whitespace)
    }
}

extension UIColor {
    
    convenience init(hexString: String) {
        let hex = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int = UInt32()
        
        Scanner(string: hex).scanHexInt32(&int)
        let a, r, g, b: UInt32
        
        switch hex.count {
            case 3: // RGB (12-bit)
                (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
            case 6: // RGB (24-bit)
                (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
            case 8: // ARGB (32-bit)
                (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
            default:
                (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: CGFloat(a) / 255)
    }
}


